Orig 18/12/29

IMPORTANT: 

Typography section comments out lists

Also open sans is default font in variables ~ line 41