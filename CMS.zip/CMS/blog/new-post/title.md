::: title
###### Snowdrop. Did you know: The Species name 'Galanthus' comes from the Greek: 'Gala' meaning milk and 'Anthos' meaning flower.
:::