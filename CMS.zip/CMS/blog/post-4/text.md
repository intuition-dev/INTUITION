::: capital
Maecenas vel vestibulum dolor. Phasellus vitae sem suscipit, vulputate erat at, dapibus leo. Aliquam ut massa vitae ex porta bibendum. Vestibulum vitae est consectetur, molestie dui nec, dapibus mi. Etiam risus elit, cursus a eleifend in, egestas at neque. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Aliquam nisl sapien, euismod eget ipsum quis, finibus sollicitudin est. Praesent vulputate interdum tristique. Morbi at condimentum tellus, vel fringilla risus. Quisque euismod imperdiet volutpat. Praesent malesuada ut urna pharetra eleifend. Vivamus eu sapien lacus. Maecenas eu ligula orci.
:::

Maecenas vel vestibulum dolor. Phasellus vitae sem suscipit, vulputate erat at, dapibus leo. Aliquam ut massa vitae ex porta bibendum. Vestibulum vitae est consectetur, molestie dui nec, dapibus mi. Etiam risus elit, cursus a eleifend in, egestas at neque. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Aliquam nisl sapien, euismod eget ipsum quis, finibus sollicitudin est. Praesent vulputate interdum tristique. Morbi at condimentum tellus, vel fringilla risus. Quisque euismod imperdiet volutpat. Praesent malesuada ut urna pharetra eleifend. Vivamus eu sapien lacus. Maecenas eu ligula orci.

Maecenas vel vestibulum dolor. Phasellus vitae sem suscipit, vulputate erat at, dapibus leo. Aliquam ut massa vitae ex porta bibendum. Vestibulum vitae est consectetur, molestie dui nec, dapibus mi. Etiam risus elit, cursus a eleifend in, egestas at neque. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Aliquam nisl sapien, euismod eget ipsum quis, finibus sollicitudin est. Praesent vulputate interdum tristique. Morbi at condimentum tellus, vel fringilla risus. Quisque euismod imperdiet volutpat. Praesent malesuada ut urna pharetra eleifend. Vivamus eu sapien lacus. Maecenas eu ligula orci.

::: fixed-bg
::: sticky-element container
## Lorem ipsum dolor sit amet, consectetur adipisicing elit
:::
:::

::: soc-links
[LinkedIn](http://www.linkedin.com/in/vic-c/)
:::