tsc
ts-node index.ts