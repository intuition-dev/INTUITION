class ApiService {
    constructor(username, password) {
        this.service = axios.create({
            baseURL: window.env == 'isProd' ? window.DEV_API[0] : window.LOCAL_API[0],
            auth: {
                username: username,
                password: password
            },
            responseType: 'json'
        });

        this.service.interceptors.response.use(function(response) {
            // Do something with response data
            console.log('response', response);
            return response;
        }, function(error) {
            // With response error redirect
            if (typeof error.response === 'undefined') {
                window.sessionStorage.setItem('errorMessage', 'Network Error');
                window.location = '/';
            } else if (401 === error.response.status) {
                window.sessionStorage.setItem('errorMessage', 'Access denied');
                window.location = '/';
            }
            return Promise.reject(error);
        });
    }

    // get data for editors table
    getEditorsList() {
        return this.service.get('/auth/editors');
    }

    // add user to collection throught node to FS
    addEditor(name, email, password) {
        return this.service.post('/auth/editors', {
            name: name,
            email: email,
            password: password
        });
    }

    // edit user to collection throught node to FS
    editEditor(uid, name) {
        return this.service.put('/auth/editors', {
            name: name,
            uid: uid
        });
    }

    // delete user to collection throught node to FS
    deleteEditor(uid) {
        return this.service.delete('/auth/editors', {
            params: {
                uid: uid
            }
        });
    }

}