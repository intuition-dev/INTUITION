#!/bin/bash
tsc
ts-node index.ts
