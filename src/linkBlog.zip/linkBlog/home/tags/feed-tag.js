
riot.tag2('feed-tag', '<div class="flex"><virtual each="{items}"><a class="item" href="{url}"> <div class="columns"> <div class="column"> <figure class="image"><img class="cardImg" riot-src="{image}"></figure> </div> <div class="column"><br> <p class="title is-5">{content_text}</p> <div class="media"> <div class="media-left"> <figure class="image is-48x48"><img riot-src="{author.avatar}"></figure> </div> <div class="media-content"> <p class="subtitle is-6">{author.name}</p> </div> </div> </div> </div></a></virtual></div><br>', 'feed-tag .item,[data-is="feed-tag"] .item{ width: 600px; height: 300px ; margin: 10px; overflow: hidden; background: white; border-style: outset; border-width: .05px; border-color: #DCDCDC; } feed-tag .cardImg,[data-is="feed-tag"] .cardImg{ height: 300px !important; width: 400px !important; object-fit: cover; }', '', function(opts) {
    console.log('oh hi tag')
    this.on('*', function(evt) {

    })
    this.items = []
    thiz = this

    this.render = function(data) {
       if(!data ) {
          thiz.items = []
          thiz.update()
          return
       }
       console.log(Object.keys(data[0]))
       thiz.items = data

      let sz = thiz.items.length
      for(i = 0; i < sz; i++) {
          var item = thiz.items[i]
          item.url = ROOT + '/blog/' + item.url
          console.log(item.url)
       }

       thiz.update()

    }.bind(this)
});