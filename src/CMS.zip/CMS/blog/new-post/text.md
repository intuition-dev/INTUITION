# Snowdrop {.style-me}

Galanthus is a small genus of about 20 species of bulbous perennial herbaceous plants in the family Amaryllidaceae. The plants have two linear leaves and a single small white drooping bell shaped flower with six petal-like tepals in two circles. The smaller inner petals have green markings.

[LinkedIn](http://www.linkedin.com/in/vic-c/)


[//]: # (http://github.com/arve0/markdown-it-attrs)