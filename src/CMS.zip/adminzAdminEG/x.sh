tsc
node index*.js