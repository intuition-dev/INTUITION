# ~/goofys --profile default -o allow_other --use-content-type orgblog2 ~/adminEG/prod

~/goofys --profile default -o allow_other --use-content-type BUCKET-NAME ~/adminEG/prod
