1. put services.js here
2. rename service.js to webAdmin.js
3. generate docs here.