#!/bin/bash
tsc
node index*.js
