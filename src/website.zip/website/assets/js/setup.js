
$(document).ready(function () {
    // are we running in native app or in a browser?
    window.isphone = false
    if (document.URL.indexOf("http://") === -1
        && document.URL.indexOf("https://") === -1) {
        window.isphone = true
    }

    console.log('phonegap?', window.isphone)
    if (window.isphone) { // //file is a browser
        document.addEventListener("deviceready", onDeviceReady, false)
    } else {
        onDeviceReady()
    }
})

onDeppLoaded()
function onDeppLoaded() {
   depp.define({
   'pre': [
      'https://cdn.jsdelivr.net/npm/js-offcanvas@1.2.6/dist/_js/js-offcanvas.pkgd.js'
      , 'https://cdn.jsdelivr.net/npm/js-offcanvas@1.2.6/dist/_css/prefixed/js-offcanvas.css'
      , ROOT + 'assets/css/gridform.css'
      //, 'https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css'
      //, 'https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js'
      //, 'https://cdn.datatables.net/fixedheader/3.1.5/css/fixedHeader.dataTables.min.css'
      //, 'https://cdn.datatables.net/select/1.2.7/css/select.dataTables.min.css'

      , 'https://cdn.jsdelivr.net/npm/zenscroll@4.0.2/zenscroll-min.js'
      //, 'https://cdn.jsdelivr.net/npm/blueimp-load-image@2.19.0/js/load-image.all.min.js'
      , 'https://cdn.jsdelivr.net/npm/is_js@0.9.0/is.min.js'
      , 'https://cdn.emailjs.com/sdk/2.2.4/email.min.js'
      , 'https://cdn.rawgit.com/terrylinooo/jquery.disableAutoFill/92cb6f86/src/jquery.disableAutoFill.js'
      ]

   /*, 'd2': [ 'pre'
      , 'https://cdn.datatables.net/select/1.2.7/js/dataTables.select.min.js'
      ,'https://cdn.datatables.net/fixedheader/3.1.5/js/dataTables.fixedHeader.min.js'
      ]*/

   , 'css': [ 'pre' //d2
      , ROOT + 'assets/css/spectre.css'
      //, ROOT + 'assets/css/nav.css'
      , ROOT + 'assets/css/main.css'
      , 'css!https://fonts.googleapis.com/css?family=Open+Sans'
      , 'css!https://fonts.googleapis.com/css?family=Playfair+Display'
      ]
   })//define

   depp.require(['pre'], setup) //d2
} //()

/*loadjs([
   //'https://cdn.jsdelivr.net/npm/signals@1.0.0/dist/signals.min.js'
   //'https://cdn.jsdelivr.net/npm/intersection-observer@0.5.0/intersection-observer.js'

   ROOT + 'assets/css/gridform.css'
   , 'https://cdn.jsdelivr.net/npm/zenscroll@4.0.2/zenscroll-min.js'

   //, 'https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css'
   //, 'https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js'
   , 'https://cdn.jsdelivr.net/npm/is_js@0.9.0/is.min.js'
   //, 'https://cdn.jsdelivr.net/npm/animejs@2.2.0/anime.min.js'

   , 'https://cdn.emailjs.com/sdk/2.2.4/email.min.js'
   , 'https://cdn.rawgit.com/terrylinooo/jquery.disableAutoFill/92cb6f86/src/jquery.disableAutoFill.js'

], 'cssJs')*/

function onDeviceReady() { // nothing will work before this
    console.log('deviceready!')
    loadjs.done('device')
}

/*function cssLoaded() {// called by the style sheet in layout
    loadjs.done('css')
}*/

/*loadjs.ready(['css', 'device', 'cssJs'], function () {
    loadjs.done('style')
})*/

let _scSz = true
function setupUserSzSc() {
    $(window).scroll(function () {
        _scSz = true
    })
    $(window).resize(function () {
        _scSz = true
    })
}//()

// usage: ////////////////////////////////////////////////////////////////////
function setup() {// 'show' page, ex: unhide
    depp.require(['css'])

    setupUserSzSc()

    if (!is.desktop()) { // mobile browser bar resize
        const viewportHeight = $('.section').outerHeight()
        console.log(viewportHeight)
        $('.section').css({ 'min-height': viewportHeight })
    }

    console.log('setup zen')
    zenscroll.setup(null, 0)

    $('.delayShowing').removeClass('delayShowing') // show

    setInterval(function () {
        if (_scSz) {
            _scSz = false
            userSzSc()
        }
    }, 150)
    console.log('style done', Date.now() - _start)
}//ready

function inView(el) { // is element in viewport
    //special bonus for jQuery
    if (typeof jQuery === "function" && el instanceof jQuery) {
        el = el[0];
    }

    var rect = el.getBoundingClientRect()

    return (
        rect.top >= 0 &&
        rect.left >= 0 &&
        rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) && /*or $(window).height() */
        rect.right <= (window.innerWidth || document.documentElement.clientWidth) /*or $(window).width() */
    )
}
