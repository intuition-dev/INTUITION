rsync --progress -r -u . "/Users/code/Library/Group Containers/G69SCX94XU.duck/Library/Application Support/duck/Volumes/S3 all/metabake"
