Uses navJBar menu 

Remove all FX other than nav as first version

