
riot.tag2('card-tag', '<div class="cards"><virtual each="{items}"> <virtual if="{publish}"> <div class="item-wrap"><a class="item" href="{url}"> <div class="img-wrap" href="{url}"><img riot-src="{image}"></div> <div class="cardInfo"> <div> <h6 class="cAccent">{name}</h6> </div> <div> <h6 class="black">{position}</h6> </div> </div></a></div></virtual> </virtual> </div><br>', '', '', function(opts) {
    console.log('oh hi tag')
    this.on('*', function(evt) {
       console.log('riot', evt)
    })
    this.items = []
    thiz = this

    this.render = function(data) {
       console.log(data)
       if(!data ) {
          thiz.items = []
          thiz.update()
          return
       }
       console.log(Object.keys(data[0]))

       let cloned = JSON.parse(JSON.stringify(data))
       thiz.items = cloned

      let sz = thiz.items.length
      for(i = 0; i < sz; i++) {
          var item = thiz.items[i]

          item.image = ROOT + 'team/' + item.url + '/who.jpg'
          item.url = ROOT + 'team/' + item.url
          console.log(item.url)
       }

       thiz.update()

    }.bind(this)
});