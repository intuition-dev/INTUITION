
riot.tag2('card-tag', '<div class="cards"><virtual each="{items}"><a class="flex left item" href="{url}"> <div class="cardInfo"> <div> <h6 class="cAccent">{name}</h6> </div> <div> <h6 class="black">{title}</h6> </div> </div></a></virtual></div><br>', 'card-tag .cards,[data-is="card-tag"] .cards{ display: flex; flex-wrap: wrap; justify-content: center; align-content: flex-start; } card-tag .cards:after,[data-is="card-tag"] .cards:after{ content: \'\'; width: 200px; } card-tag .cardInfo,[data-is="card-tag"] .cardInfo{ padding: 15px; } card-tag .item,[data-is="card-tag"] .item{ width: 200px; height: 100px ; margin: 10px; overflow: hidden; background: white; border-style: outset; border-width: .05px; border-color: #DCDCDC; }', '', function(opts) {
    console.log('oh hi tag')
    this.on('*', function(evt) {
       console.log('riot', evt)
    })
    this.items = []
    thiz = this

    this.render = function(data) {
       console.log(data)
       if(!data ) {
          thiz.items = []
          thiz.update()
          return
       }
       console.log(Object.keys(data[0]))

       let cloned = JSON.parse(JSON.stringify(data))
       thiz.items = cloned

      let sz = thiz.items.length
      for(i = 0; i < sz; i++) {
          var item = thiz.items[i]

          item.image = ROOT + 'team/' + item.url + '/who.jpg'
          item.url = ROOT + 'team/' + item.url
          console.log(item.url)
       }

       thiz.update()

    }.bind(this)
});