
## Who is Victor Cekvenich?

Software engineer and visionary...

Victor is the founder of MetaBake and a seasoned technology executive with experience with large-scale software development, team building, low-code development, network programming, practical approach to architecture, agile, CMS, distributed/network computing HTML5, CSS, node, mobile, Java, API, product, and a sought-after speaker.

At the beginning of his career, he worked on performance optimization and many startups. Some highlights over 25 years include working at NASA, publishing an early book on Java, before switching to front-end and node/javascript, and won trainer of the year by JDJ.

That experience helps with perspective. Victor prides himself with being a trailblazer. Active on github and in development community.
