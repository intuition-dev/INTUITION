
There are many good static gen offerings. Hugo, Pelican, Jekyll, etc.

MetaBake (mBake):
- Use Pug, .md (markdown)
- Can use *ANY* layout or CSS framework
- Handles dynamic data, eg: Google FireStore.
- Supports AMP
- Supports PhoneGap
