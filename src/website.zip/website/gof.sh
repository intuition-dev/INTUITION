

~/goofys --endpoint sfo2.digitaloceanspaces.com --profile default -o allow_other --use-content-type metabake ~/hosting/metabake


~/goofys --endpoint sfo2.digitaloceanspaces.com --profile default -o allow_other --use-content-type metablog ~/hosting/metablog