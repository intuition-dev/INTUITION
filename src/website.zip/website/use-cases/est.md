

For estimate, lets assume a 15 screen|page web-app, and 4 iterations: about $30K
and about double for mobile(~native).

