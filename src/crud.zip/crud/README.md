
- You should know some Firestore  already.
- Tutorial would show datatable, form and signals ahead

- Then, all together, the RW 

- It has a helper lib, rw.js

- And an obfuscated setup tag in the layout folder.

- Best way to get started? Copy the RW folder('screen)

- Validation can be done via loaded is.js or other similar js tools, eg validate.js

Demo: http://youtube.com/watch?v=B-mSA71S7VY