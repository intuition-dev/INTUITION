
Read up on Firestore auth and CRUD on their web site.

module folder has curd.pug

1. Include crud.pug in module/layout.

2. Configure FireStore on their home page.

3. Show Auth

4. Show CRUD in memebersPro
