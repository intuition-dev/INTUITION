
Video demo: [Video Demo](https://youtu.be/VelUBKcwbQY)

You can run as http app if you have an http server, webroot is in app/www

npm i # to setup

npm start # to run

To create an exe:
npm run package-win

App is in /app

Also contains page transition effects.

Note: Pay attention to ROOT in dat.yaml