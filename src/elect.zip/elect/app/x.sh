# mbake .
npm start