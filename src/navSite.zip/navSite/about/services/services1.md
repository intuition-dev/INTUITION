
- Real assets that provide essential services for the economy and community
- High barriers to entry and monopolistic qualities based on contractual terms or regulatory regime and/or location
- Predictable, long term cash flow underpinned by contracts or regulatory regime
- Provide both current return and capital appreciation potential
