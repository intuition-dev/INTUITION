
loadjs([
 '/assets/css/gridforms/gridforms.css'
], 'cssJs')

function cssLoaded() {
   console.log('css')
}
