
loadjs([
 'https://unpkg.com/vivid-icons@1.0.9/dist/vivid-icons.min.js'
   , '/assets/css/gridforms/gridforms.css'
], 'cssJs')

function cssLoaded() {
   console.log('css')
}
