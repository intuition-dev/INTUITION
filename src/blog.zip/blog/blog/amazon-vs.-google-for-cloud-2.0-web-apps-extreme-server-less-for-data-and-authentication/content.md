A decade ago we grudgingly moved from data centers to the Cloud Version 1: AWS, Google, etc. These days we are moving to Cloud Version 2. I see Cloud 2.0 as ‘extreme server-less’ and ‘client-side only’. This means that you only write code for the browser or your mobile app; you don’t write __any code__ that runs on the server. How many times have we all written user authentication? With Cloud 2.0, you will not ever have to do that again. How awesome this that? Let’s take a closer look.

## Step 1: Which platform to host your static files?

AWS S3 static hosting is more popular than Firebase. One reason may be that that you can mount an S3 ‘bucket’ filesystem as a drive on your local development machine; Firebase doesn’t allow that. Having your dev or prod server files accessible under, say, “P:\” means that you don’t have to FTP your files any more. Any edits in ‘your’ drive will automatically be reflected on that server and in the web browser. That makes for a nice bump in developer productivity. I use WinDrive to mount S3 buckets.

## Step 2: Which database?

Just because you host your static files on S3 doesn’t mean that you are tied to AWS for everything else. I want to use a best-of-breed strategy. This leads me to a multi-cloud approach.

For database CRUD operations (create-read-update-delete) we had to learn new database systems, including no-SQL types such as Mongo. Then we had to write ORM, REST, and we had to operate them securely. It’s time to learn again!

Google Firestore (Version 2 of Firebase) seems to be a better database than AWS Amplify. While version 1 of Firebase felt confusing, its version 2 — Firestore — has come a long way in terms of ease of use and ease of client-side JavaScript coding. And that’s all we do with the database in Cloud 2.0: we write client-side JavaScript against it. As a result, we choose Firestore as our database.

## Step 3: Which user authentication?

You can use either AWS Amplify/Cognito/S3 or Google Firebase/Firestore to avoid rolling your own user authentication. Others like Auth0 or Okta offer similar functionalities. I rate them less attractive while they want to inject their own branding into the UI of my app.

Using Firestore for database CRUD leads us to using Firebase for user authentication.

See example code [here](https://github.com/metabake/Metabake-examples/tree/master/examples/crud/screen)

You can do:
```
npm -g i mbake
mbake -c
```
to get a sample Cloud 2.0 CRUD and user authentication app from METABAKE.ORG. It uses S3 hosting and a Firestore database.

The sample code shows how to register with an email address:

```
auth.createUserWithEmailAndPassword(email,pswd)
```

Of course it also offers user log-in via Facebook, Twitter, Gmail, etc — all without any serverside coding!

Other snippets:

```
auth.signInWithEmailAndPassword(email,pswd)
auth.signOut()
auth.sendPasswordResetEmail(email)
```

## Conclusion

We need to learn new skills to use Cloud 2.0. That also means unlearning old habits. Like when we went from 2GL to 3GL, we now do less things: we write less code — and different code.

Your next step would be to learn how to do ‘low-code’ data binding. Cloud 2.0 also means moving past old approaches like Vue, Angular or React.

To learn this approach, check out [METABAKE.ORG](https://metabake.org), where we evangelize the extreme server-less, low-code Cloud 2.0.





