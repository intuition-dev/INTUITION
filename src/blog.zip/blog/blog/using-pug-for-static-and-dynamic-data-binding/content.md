You may have heard of *Pug* — the Node Express rendering engine uses it. If not, you can think of it as *Markdown* but with more features.

Pug markup translates 1:1 to HTML, but without having to close a tag. On a previous Wordpress project, someone changed a CSS, and it broke the layout on some browsers. 10 (ten!) days later, we found the bug: It was not CSS, but that someone had not closed a tag. With Pug that would not have happened.

Some CMS systems use Markdown for content. However, you can’t change *layouts* or page composition in Markdown. In Pug, you can. The pug ‘include’ feature helps with sharing layouts across multiple pages.

Pug also has *variables*. You can use that for *static data binding*. You don’t need to run Node Express to be able to use Pug. To setup, first install a CLI that can merge Pug with data files:

```
yarn global add mbake
```

Now, using your editor, create ‘dat.yaml’ with:

```
key1: value1
```

and create ‘index.pug’ with:

```
    doctype html
    html
       head
       body
          p #{key1}
```

and now run:

```
mbake .
```

It will generate index.html with

```
<!DOCTYPE html>
<html>
   <head/>
   <body>
      <p>value1</p>
   </body>
</html>
```

Imagine what you can do with that. Static data binding with Pug is a great foundation for statically generated sites. Check out the static site generators Hugo, Jekyll and Metabake. We like Metabake because we wrote it :-)

You can also use Pug for *dynamic data binding*. That is when data is combined with markup runtime, i.e. in the browser. That allows you to display data that comes from JSON files or API calls.

Create a file ‘first-tag.pug’ with:

```
first-tag
   p Dynamic Data:
   p { num }

  script.
     doSomething(arg) {
       console.log('arg: ', arg)
       this.update({num: arg})
     }
```

When doSomething() gets called, it updates the {num}.

Run this to to generate a .js file that you can include in your page:

```
mbake -t .
```

For a complete example, see <https://github.com/metabake/Metabake-examples/tree/master/examples/website/riotFirst>

You can read up more at <https://riotjs.com> and <http://doc.metabake.org/mbake/>.

In summary, you can use Pug for layout, static binding and dynamic binding. Pug is declarative and ‘low-code’. You’ll find that it improves your development productivity a lot.


