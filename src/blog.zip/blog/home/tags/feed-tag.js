
riot.tag2('feed-tag', '<div class="container"> <div class="columns col-gapless"><virtual each="{items}"> <div class="column col-sm-12 col-md-6 col-xl-4"><a class="card" href="{url}"> <div class="card-image"><img class="img-responsive" riot-src="{image}"></div> <div class="card-header"> <h5 class="card-title">{title}</h5> </div></a></div></virtual> </div> </div><br>', '', '', function(opts) {
    console.log('oh hi tag')
    this.on('*', function(evt) {

    })
    this.items = []
    thiz = this

    this.render = function(data) {
    	if(!data ) {
    		thiz.items = []
    		thiz.update()
    		return
    	}
    	console.log(Object.keys(data[0]))

    	let cloned = JSON.parse(JSON.stringify(data))
    	thiz.items = cloned

      let sz = thiz.items.length
      for(i = 0; i < sz; i++) {
    		var item = thiz.items[i]
    		item.url = ROOT + 'blog/' + item.url
    		if (item.image.indexOf('//')==-1)
    			 item.image = item.url + '/' + item.image

    		console.log(item.url)
    	}

    	thiz.update()

    }.bind(this)
});