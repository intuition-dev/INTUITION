clear
tsc
node crudSrv.js 