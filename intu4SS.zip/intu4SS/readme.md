
<img src="http://MetaBake.github.io/mbakeDocs/logo.jpg" width="100">

Like CMS but with items for sale.

