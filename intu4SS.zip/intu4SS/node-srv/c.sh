# to clear 
rm *.js
find . -name *.js -delete
