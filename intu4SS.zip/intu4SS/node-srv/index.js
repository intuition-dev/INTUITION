"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const IntuSrv_1 = require("intu/node-srv/IntuSrv");
const SDB_1 = require("./lib/SDB");
const SnipHook_1 = require("./lib/SnipHook");
const db = new SDB_1.SDB();
const mainEApp = new IntuSrv_1.IntuApp(db, ['*']);
const snipHook = new SnipHook_1.SnipHook(db);
mainEApp.appInst.post('/api/snipHook/', snipHook.handleWebHook);
mainEApp.serveStatic('../www');
mainEApp.appInst.all('*', function (req, resp) {
    const path = req.path;
    console.log('no route', path);
    resp.json({ 'No route': path });
});
mainEApp.appInst.listen(8888, () => {
    console.info('server running on port: 8888');
});
