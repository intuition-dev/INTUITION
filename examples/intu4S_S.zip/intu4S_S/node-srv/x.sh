clear
tsc
node index.js