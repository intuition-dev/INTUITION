mbake .
mbake -t .
mbake-x -c .
mbake -s assets
mbake-x -w . -p 3005 -r 9805