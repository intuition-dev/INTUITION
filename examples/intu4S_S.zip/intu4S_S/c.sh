find . -name *.html -delete
