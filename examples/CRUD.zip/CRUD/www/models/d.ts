declare let iViewModel:any
