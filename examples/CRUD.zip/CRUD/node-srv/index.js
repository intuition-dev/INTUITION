"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Routers_1 = require("./routes/Routers");
const IntuApp_1 = require("intu/node-srv/IntuApp");
const IDB_1 = require("intu/node-srv/lib/IDB");
const AppLogic_1 = require("intu/node-srv/lib/AppLogic");
const CDB_1 = require("./lib/CDB");
const logger = require('tracer').console();
const idb = new IDB_1.IDB(process.cwd(), '/IDB.sqlite');
const mainIApp = new IntuApp_1.IntuApp(idb, ['*']);
async function app() {
    const cdb = new CDB_1.CDB(process.cwd(), '/CDB.sqlite');
    const setupDone = await cdb.isSetupDone();
    logger.trace('app', setupDone);
    const cRouter = new Routers_1.CrudPgRouter(cdb);
    mainIApp.handleRRoute('capi', 'CRUD1Pg', cRouter.route.bind(cRouter));
    mainIApp.serveStatic('..' + '/www');
    mainIApp.appInst.all('*', function (req, resp) {
        const path = req.path;
        logger.trace('no route', path);
        resp.json({ 'No route': path });
    });
    mainIApp.listen(8080);
}
async function runISrv() {
    const setupDone = await idb.isSetupDone();
    logger.trace('?', setupDone);
    let intuPath = AppLogic_1.Util.appPath + '/node_modules/intu/INTU';
    logger.trace(intuPath);
    if (setupDone) {
        logger.trace('normal');
        await mainIApp.run(intuPath);
    }
    else {
        logger.trace('run setup');
        await mainIApp.run(intuPath);
    }
    console.log('######################################', 'intu ready');
    app();
}
runISrv();
