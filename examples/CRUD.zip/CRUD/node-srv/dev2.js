"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const IDB_1 = require("intu/node-srv/lib/IDB");
const idb = new IDB_1.IDB(process.cwd(), '/IDB.sqlite');
async function f() {
    await idb.isSetupDone();
}
f();
