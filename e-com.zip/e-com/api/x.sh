tsc

node index.js