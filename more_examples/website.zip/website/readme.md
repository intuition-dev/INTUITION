
You just need index.pug and dat.yaml in a folder to 'mbake'.
