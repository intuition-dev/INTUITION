
riot.tag2('shopitem-comp', '', '', '', function(opts) {
});