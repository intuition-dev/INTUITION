


export class Vere {
   static ver() {
      return 'v0.5.1'
   }
}


module.exports = {
 Vere
}
