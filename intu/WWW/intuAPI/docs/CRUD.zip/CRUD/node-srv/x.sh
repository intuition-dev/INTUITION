clear
tsc
#node index.js
node dev.js