clear
tsc
#node index.js
node index.js