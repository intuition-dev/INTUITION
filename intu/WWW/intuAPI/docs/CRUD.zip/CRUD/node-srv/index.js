"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Routers_1 = require("./routes/Routers");
const IntuSrv_1 = require("intu/node-srv/IntuSrv");
const ADB_1 = require("intu/node-srv/lib/ADB");
const adbDB = new ADB_1.ADB();
const mainEApp = new IntuSrv_1.IntuApp(adbDB, ['*']);
mainEApp.appInst.use(function (req, res, next) {
    if (true)
        console.log('Time:', Date.now());
    next();
});
mainEApp.serveStatic('../ed');
const cRouter = new Routers_1.CrudPgRouter();
mainEApp.handleRRoute('api', 'CRUD1Pg', cRouter.route.bind(cRouter));
mainEApp.serveStatic('../www');
mainEApp.appInst.all('*', function (req, resp) {
    const path = req.path;
    console.log('no route', path);
    resp.json({ 'No route': path });
});
mainEApp.appInst.listen(8888, () => {
    console.info('server running on port: 8888');
});
