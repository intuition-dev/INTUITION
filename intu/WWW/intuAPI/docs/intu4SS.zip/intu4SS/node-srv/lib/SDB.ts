
import { ADB } from 'intu/node-srv/lib/ADB';

export class SDB extends ADB {

    
    addTable() {

    }

    getAPIs() { // shipping api and maybe shoping api

    }

}//class



