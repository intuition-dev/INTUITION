
like CMS but with pictures of items for sale.

## Configs needed

**add config.yaml to the shippingAPI with your printful api**