

// client calls snip cart server directly

// webhook that it was paid

// it then calls BL to ship

// it then emails that it was shipped

