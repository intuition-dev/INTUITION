console.log('qtests-loader')

depp.require('poly', load)

function load() {
   var pro = loadQunit()

}